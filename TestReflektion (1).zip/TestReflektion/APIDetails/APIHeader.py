"""
This class is is used to mention all the API Headers\

"""

class ApiHeader:
    headers = {"Content-Type": "application/json","charset" : "UTF-8"}
