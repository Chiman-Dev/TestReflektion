"""
This class is is used to mention all the API end points
this con be optimized to run APi in different env, as of now its hard coded

"""

class ApiDetails:

    fetchRecords1 = "https://jsonplaceholder.typicode.com/posts"
    fetchRecords2="https://jsonplaceholder.typicode.com/posts"
    fetchRecords3="https://jsonplaceholder.typicode.com/invalidposts"
    postRecords="https://jsonplaceholder.typicode.com/posts"
    putRecords="https://jsonplaceholder.typicode.com/posts/1"
    deleteRecords="https://jsonplaceholder.typicode.com/posts/1"

