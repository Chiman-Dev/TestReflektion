class ApiPayload:
    body = {
        "title": "foo",
        "body": "bar",
        "userId": 1
    }
    putBody = {
        "id": 1,
        "title": "abc",
        "body": "xyz",
        "userId": 1
    }
